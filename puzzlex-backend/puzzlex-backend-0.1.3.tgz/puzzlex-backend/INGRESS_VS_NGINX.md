# Ingress vs 独立 Nginx 容器功能对比

## 架构差异

### Docker Compose 架构（之前）
```
Internet → Nginx 容器 → Backend 容器 (3000)
```

### Kubernetes 架构（现在）
```
Internet → Nginx Ingress Controller → Service → Pod (Web/Cable)
```

## 功能对比表

| Nginx 配置项 | Ingress 实现方式 | 状态 |
|------------|----------------|------|
| **反向代理** | Ingress Controller 自动处理 | ✅ 已实现 |
| **WebSocket 支持** | `nginx.ingress.kubernetes.io/websocket-services` | ✅ 已配置 |
| **超时配置** | `proxy-read-timeout`, `proxy-send-timeout` | ✅ 已配置 |
| **请求体大小** | `proxy-body-size: 100m` | ✅ 已配置 |
| **Gzip 压缩** | Nginx Ingress Controller 默认启用 | ✅ 自动启用 |
| **Cloudflare 真实 IP** | 通过 `CF-Connecting-IP` 头传递 | ✅ 已配置 |
| **静态资源缓存** | 通过后端 `Cache-Control` 响应头 | ⚠️ 需后端配合 |
| **请求限流** | `limit-rps`, `limit-connections` | 📝 可选配置 |
| **健康检查** | K8S Liveness/Readiness Probes | ✅ 已配置 |
| **SSL/TLS** | Ingress TLS 或 Cloudflare | ✅ 支持 |

## 详细说明

### ✅ 已实现的功能

#### 1. WebSocket 支持
- **Nginx 配置**: `proxy_set_header Upgrade $http_upgrade;`
- **Ingress 实现**: `nginx.ingress.kubernetes.io/websocket-services: "puzzlex-backend-cable"`
- **说明**: Ingress Controller 会自动处理 WebSocket 升级

#### 2. 超时配置
- **Nginx 配置**: `proxy_read_timeout 60s` (普通), `86400` (WebSocket)
- **Ingress 实现**: 
  - `proxy-read-timeout: "3600"` (WebSocket 长连接)
  - `proxy-connect-timeout: "60"`
- **说明**: Ingress 的超时配置会应用到所有路由

#### 3. 请求体大小
- **Nginx 配置**: `client_max_body_size 100M`
- **Ingress 实现**: `proxy-body-size: "100m"`
- **说明**: 完全一致

#### 4. Cloudflare 真实 IP
- **Nginx 配置**: `real_ip_header CF-Connecting-IP;` + `set_real_ip_from`
- **Ingress 实现**: 
  - Cloudflare 自动设置 `CF-Connecting-IP` 头
  - 通过 `configuration-snippet` 传递 `X-Real-IP` 和 `X-Forwarded-For`
- **注意**: 如果需要在 Ingress Controller 层面配置 `set-real-ip-from`，需要修改 Nginx Ingress Controller 的 ConfigMap

#### 5. Gzip 压缩
- **Nginx 配置**: `gzip on;` + 各种 gzip 配置
- **Ingress 实现**: Nginx Ingress Controller 默认启用 Gzip
- **说明**: 无需额外配置

### ⚠️ 需要调整的功能

#### 1. 静态资源缓存
- **Nginx 配置**: 
  ```nginx
  location ~ ^/(assets|packs)/ {
      proxy_cache_valid 200 1y;
      add_header Cache-Control "public, immutable";
      expires 1y;
  }
  ```
- **Ingress 实现**: 
  - **方案1**: 在后端应用（Rails）中设置 `Cache-Control` 响应头
  - **方案2**: 使用单独的 Ingress 规则配置缓存策略
  - **方案3**: 使用 CDN（如 Cloudflare）缓存静态资源
- **推荐**: 使用方案1，在 Rails 的 `config/environments/production.rb` 中配置：
  ```ruby
  config.public_file_server.headers = {
    'Cache-Control' => 'public, max-age=31536000, immutable'
  }
  ```

#### 2. 请求限流
- **Nginx 配置**: `limit_req_zone` + `limit_req`
- **Ingress 实现**: 
  ```yaml
  nginx.ingress.kubernetes.io/limit-rps: "100"
  nginx.ingress.kubernetes.io/limit-connections: "10"
  ```
- **说明**: 已在 values.yaml 中注释，需要时可启用

### 📝 不需要的功能

#### 1. 独立的健康检查端点
- **Nginx 配置**: `location = /nginx-health`
- **K8S 实现**: 使用 K8S 的 Liveness/Readiness Probes
- **说明**: K8S 的健康检查机制更强大，不需要单独的 nginx 健康检查端点

#### 2. 日志配置
- **Nginx 配置**: `access_log`, `error_log`
- **K8S 实现**: Nginx Ingress Controller 默认记录日志，可通过 Controller 的 ConfigMap 配置格式
- **说明**: 日志会自动收集到 K8S 日志系统中

## 迁移建议

### ✅ 可以删除的内容
1. **独立的 Nginx 容器**: `deployment/docker/nginx/` 目录下的文件
2. **Docker Compose 中的 nginx 服务**: `docker-compose.prod.yml` 中的 nginx 服务定义

### ⚠️ 需要配置的内容
1. **Nginx Ingress Controller**: 确保集群中已安装 Nginx Ingress Controller
   ```bash
   kubectl get ingressclass
   ```
2. **Cloudflare IP 白名单**: 如果需要在 Ingress Controller 层面配置，需要修改 Controller 的 ConfigMap
3. **静态资源缓存**: 在后端应用中配置 `Cache-Control` 响应头

### 📋 部署前检查清单
- [ ] Nginx Ingress Controller 已安装
- [ ] Ingress Class 名称正确（默认 `nginx`）
- [ ] Cloudflare DNS 已配置（如果使用）
- [ ] TLS 证书已准备（如果使用 HTTPS）
- [ ] 后端应用已配置静态资源缓存头

## 总结

**结论**: 在 Kubernetes 中使用 Ingress Controller 后，**不需要单独部署 nginx 容器**。所有原 nginx 的功能都可以通过 Ingress annotations 实现，或者由 Ingress Controller 自动处理。

**优势**:
- ✅ 减少资源消耗（不需要额外的 nginx Pod）
- ✅ 统一管理（所有 Ingress 规则集中管理）
- ✅ 自动负载均衡（K8S Service 自动处理）
- ✅ 更好的可观测性（K8S 原生监控和日志）

**注意事项**:
- ⚠️ 静态资源缓存需要后端应用配合
- ⚠️ Cloudflare IP 白名单需要在 Ingress Controller 层面配置（如需要）

