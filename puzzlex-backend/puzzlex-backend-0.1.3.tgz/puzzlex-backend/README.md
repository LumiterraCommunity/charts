# PuzzleX Backend Helm Chart

This Helm chart deploys the PuzzleX Backend application on Kubernetes, including three main services:

- **Web Service**: Rails HTTP/API server (Puma)
- **Cable Service**: Action Cable WebSocket server
- **Sidekiq Service**: Background job processor

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- A container registry with the PuzzleX Backend image

## Installation

### Basic Installation

```bash
helm install puzzlex-backend . \
  --namespace puzzlex \
  --create-namespace \
  --set image.repository=your-registry/puzzlex-backend \
  --set image.tag=latest
```

### With Environment-Specific Values

```bash
# Development
helm install puzzlex-backend . \
  -f dev.yaml \
  --namespace puzzlex-dev \
  --create-namespace

# Production
helm install puzzlex-backend . \
  -f release.yaml \
  --namespace puzzlex-prod \
  --create-namespace
```

## Configuration

### Required Secrets

Create a Kubernetes secret with the following keys:

```bash
kubectl create secret generic puzzlex-secrets \
  --from-literal=database-url='mysql://...' \
  --from-literal=puzzlex-database-url='postgresql://...' \
  --from-literal=redis-url='redis://...' \
  --from-literal=rails-master-key='...' \
  --from-literal=secret-key-base='...' \
  --namespace puzzlex
```

### Key Configuration Values

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Container image repository | `your-registry/puzzlex-backend` |
| `image.tag` | Container image tag | `latest` |
| `web.replicaCount` | Number of web service replicas | `2` |
| `cable.replicaCount` | Number of cable service replicas | `2` |
| `sidekiq.replicaCount` | Number of sidekiq replicas | `2` |
| `ingress.enabled` | Enable Ingress | `true` |
| `ingress.hosts[0].host` | Ingress hostname | `puzzlex.club` |

See `values.yaml` for all available configuration options.

## Architecture

```
Internet
   ↓
Ingress (Nginx)
   ├─ /api/* → Service (web) → Deployment (web) [Puma HTTP]
   └─ /cable → Service (cable) → Deployment (cable) [Action Cable]
   
Redis ← Deployment (sidekiq) [Sidekiq Workers]
```

## Services

### Web Service (Puma)

Handles HTTP/API requests. Exposed via Ingress at `/` (except `/cable`).

**Command**: `bundle exec rails server -b 0.0.0.0`

### Cable Service (Action Cable)

Handles WebSocket connections. Exposed via Ingress at `/cable`.

**Command**: `bundle exec puma -C config/puma.cable.rb cable/config.ru`

### Sidekiq Service

Processes background jobs. Not exposed externally.

**Command**: `bundle exec sidekiq -c 5 -v`

## Ingress Configuration

The chart creates an Ingress resource that routes:
- `/cable` → Cable service (WebSocket)
- `/` → Web service (HTTP/API)

WebSocket-specific annotations are automatically added for proper WebSocket support.

## Scaling

### Manual Scaling

```bash
# Scale web service
kubectl scale deployment puzzlex-backend-web --replicas=5 -n puzzlex

# Scale cable service
kubectl scale deployment puzzlex-backend-cable --replicas=5 -n puzzlex

# Scale sidekiq
kubectl scale deployment puzzlex-backend-sidekiq --replicas=5 -n puzzlex
```

### Auto Scaling (HPA)

Enable autoscaling in `values.yaml`:

```yaml
autoscaling:
  enabled: true
  minReplicas: 2
  maxReplicas: 10
  targetCPUUtilizationPercentage: 80
```

## Monitoring

### View Logs

```bash
# Web service logs
kubectl logs -l app.kubernetes.io/component=web -n puzzlex --tail=100

# Cable service logs
kubectl logs -l app.kubernetes.io/component=cable -n puzzlex --tail=100

# Sidekiq logs
kubectl logs -l app.kubernetes.io/component=sidekiq -n puzzlex --tail=100
```

### Check Status

```bash
# All deployments
kubectl get deployments -n puzzlex -l app.kubernetes.io/instance=puzzlex-backend

# All pods
kubectl get pods -n puzzlex -l app.kubernetes.io/instance=puzzlex-backend

# All services
kubectl get services -n puzzlex -l app.kubernetes.io/instance=puzzlex-backend
```

## Upgrading

```bash
helm upgrade puzzlex-backend . \
  --namespace puzzlex \
  --set image.tag=new-tag
```

## Uninstallation

```bash
helm uninstall puzzlex-backend --namespace puzzlex
```

## Troubleshooting

### Pods Not Starting

1. Check pod status: `kubectl describe pod <pod-name> -n puzzlex`
2. Check logs: `kubectl logs <pod-name> -n puzzlex`
3. Verify secrets exist: `kubectl get secrets -n puzzlex`

### WebSocket Not Working

1. Verify Ingress annotations include WebSocket settings
2. Check Cable service is running: `kubectl get pods -l app.kubernetes.io/component=cable`
3. Verify `/cable` path routes to Cable service in Ingress

### Sidekiq Not Processing Jobs

1. Check Sidekiq pods are running
2. Verify Redis connection in logs
3. Check Redis URL in secrets

## License

[Your License Here]

