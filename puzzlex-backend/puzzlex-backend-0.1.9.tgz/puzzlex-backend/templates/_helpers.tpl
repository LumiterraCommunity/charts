{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "puzzlex-backend.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "puzzlex-backend.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "puzzlex-backend.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "puzzlex-backend.labels" -}}
helm.sh/chart: {{ include "puzzlex-backend.chart" . }}
{{ include "puzzlex-backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "puzzlex-backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "puzzlex-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Service name for a component
*/}}
{{- define "puzzlex-backend.component.fullname" -}}
{{- printf "%s-%s" (include "puzzlex-backend.fullname" .) .component | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Labels for a component
*/}}
{{- define "puzzlex-backend.component.labels" -}}
helm.sh/chart: {{ include "puzzlex-backend.chart" . }}
{{ include "puzzlex-backend.component.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels for a component
*/}}
{{- define "puzzlex-backend.component.selectorLabels" -}}
app.kubernetes.io/name: {{ include "puzzlex-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "puzzlex-backend.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "puzzlex-backend.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Merge common env vars with component-specific env vars
*/}}
{{- define "puzzlex-backend.env" -}}
{{- $envVars := list }}
{{- if .Values.commonEnv }}
{{- $envVars = concat $envVars .Values.commonEnv }}
{{- end }}
{{- if .componentEnv }}
{{- $envVars = concat $envVars .componentEnv }}
{{- end }}
{{- if $envVars }}
{{- toYaml $envVars }}
{{- end }}
{{- end -}}
